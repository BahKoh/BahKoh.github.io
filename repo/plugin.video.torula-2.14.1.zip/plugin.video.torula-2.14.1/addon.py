import sys
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import logging
import urllib2
import json
import time

def show_feeds():
  feed_handle = int(sys.argv[1])
  xbmcplugin.setContent(feed_handle, 'tvshows')

  for slug in sorted(feeds, key=lambda x: feeds[x]['title'].lower()):
    iconPath = os.path.join(home, 'resources', 'media', 'default-live.png')
    li = xbmcgui.ListItem(feeds[slug]['title'], iconImage=iconPath)
    logging.warning('-----FEED slug!!!! %s', slug)
    url = sys.argv[0] + '?feed=' + slug
    xbmcplugin.addDirectoryItem(handle=feed_handle, url=url, listitem=li, isFolder=True)

  xbmcplugin.endOfDirectory(feed_handle)

def show_channels(slug):
  logging.warning('CHANNELS show_channels!!!! %s', slug)
  channels = sorted(feeds[slug]['channels'], key=lambda x: x['title'].lower())
  channel_handle = int(sys.argv[1])
  xbmcplugin.setContent(channel_handle, 'tvshows')

  for channel in channels:
    # if channel['disabled'] is True:
    #   continue
    #hide disabled
    xbmc.log(str(channel), xbmc.LOGERROR)
    # iconPath = os.path.join(home, 'resources', 'media', channel['icon'])
    # poster_url = "http://%s:%s/%s/poster.jpg?_=%s" % (host, port, channel['slug'], time.time())
    posterUrl = "%s?_=%s" % (channel['poster'], time.time())
    iconUrl = channel['icon']
    title = channel['title']
    li = xbmcgui.ListItem(title)
    li.setArt({'thumb': iconUrl, 'poster': iconUrl, 'fanart': posterUrl})
    url = channel['url']

    #headers
    if 'user-agent' in channel:
      url += '|User-Agent='+channel['user-agent']

    xbmcplugin.addDirectoryItem(handle=channel_handle, url=url, listitem=li)

  xbmcplugin.endOfDirectory(channel_handle)

def get_params():
  """
  Retrieves the current existing parameters from XBMC.
  """
  param = []
  paramstring = sys.argv[2]
  if len(paramstring) >= 2:
    params = sys.argv[2]
    cleanedparams = params.replace('?', '')
    if params[len(params) - 1] == '/':
      params = params[0:len(params) - 2]
    pairsofparams = cleanedparams.split('&')
    param = {}
    for i in range(len(pairsofparams)):
      splitparams = {}
      splitparams = pairsofparams[i].split('=')
      if (len(splitparams)) == 2:
        param[splitparams[0]] = splitparams[1]
  return param


def lower_getter(field):
  def _getter(obj):
    return obj[field].lower()

  return _getter

addon = xbmcaddon.Addon()
username = addon.getSetting('username')
password = addon.getSetting('password')
port = addon.getSetting('port')
host = addon.getSetting('host')
home = xbmc.translatePath(addon.getAddonInfo('path'))

feeds = {}
feeds_url = "http://%s:%s/feeds.json" % (host, port)
feeds_list = json.load(urllib2.urlopen(feeds_url))

for feed in feeds_list:
  slug = feed['slug']
  feed_url = "http://%s:%s/%s" % (host, port, feed['file'])
  logging.warning('====== feed title ======= %s', feed['title'])
  logging.warning('====== feed url ======= %s', feed_url)
  logging.warning('====== feed slug ======= %s', slug)

  feeds[slug] = feed
  feeds[slug]['channels'] = json.load(urllib2.urlopen(feed_url))

PARAMS = get_params()
FEED = None
logging.warning('PARAMS!!!! %s', PARAMS)

try:
  FEED = PARAMS['feed']
except:
    pass

logging.warning('ARGS!!!! sys.argv %s', sys.argv)

if FEED == None:
  show_feeds()
elif FEED:
  show_channels(FEED)
